const menu = [
  {
    id: 0,
    title: "아침메뉴",
    category: "아침메뉴",
    price: 1000,
    img: "./images/item-1.jpg",
    desc: `skateboard fam synth authentic semiotics. Live-edge lyft af, edison bulb yuccie crucifix microdosing.`,
  },
  {
    id: 1,
    title: "오늘의메뉴",
    category: "오늘의메뉴",
    price: 6500,
    img: "./images/item-2.jpg",
    desc: `skateboard fam synth authentic semiotics. Live-edge lyft af, edison bulb yuccie crucifix microdosing.`,
  },
  {
    id: 2,
    title: "4분돼지김치파스타",
    category: "파스타치요",
    price: 7500,
    img: "./images/item-3.jpg",
    desc: `I'm baby woke mlkshk wolf bitters live-edge blue bottle, hammock freegan copper mug whatever cold-pressed `,
  },
  {
    id: 3,
    title: "고기리들기름파스타",
    category: "파스타치요",
    price: 6000,
    img: "./images/item-4.jpg",
    desc: `vaporware iPhone mumblecore selvage raw denim slow-carb leggings gochujang helvetica man braid jianbing. Marfa thundercats `,
  },
  {
    id: 4,
    title: "트러플버섯크림파스타",
    category: "파스타치요",
    price: 6500,
    img: "./images/item-5.jpg",
    desc: `vaporware iPhone mumblecore selvage raw denim slow-carb leggings gochujang helvetica man braid jianbing. Marfa thundercats `,
  },
  {
    id: 5,
    title: "대패삼겹크림파스타",
    category: "파스타치요",
    price: 7500,
    img: "./images/item-6.jpg",
    desc: `vaporware iPhone mumblecore selvage raw denim slow-carb leggings gochujang helvetica man braid jianbing. Marfa thundercats `,
  },
  {
    id: 6,
    title: "매콤로제파스타",
    category: "파스타치요",
    price: 7500,
    img: "./images/item-7.jpg",
    desc: `vaporware iPhone mumblecore selvage raw denim slow-carb leggings gochujang helvetica man braid jianbing. Marfa thundercats `,
  },
  {
    id: 7,
    title: "우삼겹알리오올리오파스타",
    category: "파스타치요",
    price: 7000,
    img: "./images/item-8.jpg",
    desc: `vaporware iPhone mumblecore selvage raw denim slow-carb leggings gochujang helvetica man braid jianbing. Marfa thundercats `,
  },
  {
    id: 8,
    title: "직화불막창토핑추가", 
    category: "파스타치요",
    price: 2900,
    img: "./images/item-9.jpg",
    desc: `vaporware iPhone mumblecore selvage raw denim slow-carb leggings gochujang helvetica man braid jianbing. Marfa thundercats `,
  },
  {
    id: 9,
    title: "직화불쭈꾸미토핑추가",
    category: "파스타치요",
    price: 2900,
    img: "./images/item-10.jpg",
    desc: `ombucha chillwave fanny pack 3 wolf moon street art photo booth before they sold out organic viral.`,
  },

  {
    id: 10,
    title: "치킨마요덮밥",
    category: "니나노덮밥",
    price: 7000,
    img: "./images/item-11.jpg",
    desc: `franzen vegan pabst bicycle rights kickstarter pinterest meditation farm-to-table 90's pop-up `,
  },
  {
    id: 11,
    title: "우동돈까스세트",
    category: "니나노덮밥",
    price: 6200,
    img: "./images/item-12.jpg",
    desc: `Portland chicharrones ethical edison bulb, palo santo craft beer chia heirloom iPhone everyday`,
  },
  {
    id: 11,
    title: "제육덮밥",
    category: "니나노덮밥",
    price: 6500,
    img: "./images/item-13.jpg",
    desc: `carry jianbing normcore freegan. Viral single-origin coffee live-edge, pork belly cloud bread iceland put a bird `,
  },
  {
    id: 12,
    title: "닭갈비덮밥",
    category: "니나노덮밥",
    price: 7000,
    img: "./images/item-14.jpg",
    desc: `on it tumblr kickstarter thundercats migas everyday carry squid palo santo leggings. Food truck truffaut  `,
  },
  {
    id: 13,
    title: "오므라이스",
    category: "니나노덮밥",
    price: 7000,
    img: "./images/item-15.jpg",
    desc: `skateboard fam synth authentic semiotics. Live-edge lyft af, edison bulb yuccie crucifix microdosing.`,
  },
  {
    id: 14,
    title: "불닭마요덮밥",
    category: "니나노덮밥",
    price: 6500,
    img: "./images/item-16.jpg",
    desc: `skateboard fam synth authentic semiotics. Live-edge lyft af, edison bulb yuccie crucifix microdosing.`,
  },

  {
    id: 16,
    title: "제주흑돼지돈까스",
    category: "일식/양식",
    price: 6000,
    img: "./images/item-17.jpg",
    desc: `skateboard fam synth authentic semiotics. Live-edge lyft af, edison bulb yuccie crucifix microdosing.`,
  },
  {
    id: 17,
    title: "탄탄면",
    category: "일식/양식",
    price: 6500,
    img: "./images/item-18.jpg",
    desc: `skateboard fam synth authentic semiotics. Live-edge lyft af, edison bulb yuccie crucifix microdosing.`,
  },
  {
    id: 18,
    title: "냉모밀",
    category: "일식/양식",
    price: 6500,
    img: "./images/item-19.jpg",
    desc: `skateboard fam synth authentic semiotics. Live-edge lyft af, edison bulb yuccie crucifix microdosing.`,
  },
  {
    id: 19,
    title: "카레밥",
    category: "일식/양식",
    price: 4500,
    img: "./images/item-20.jpg",
    desc: `skateboard fam synth authentic semiotics. Live-edge lyft af, edison bulb yuccie crucifix microdosing.`,
  },
  {
    id: 20,
    title: "아메리카노",
    category: "샌드위치카페",
    price: 2000,
    img: "./images/item-21.jpg",
    desc: `skateboard fam synth authentic semiotics. Live-edge lyft af, edison bulb yuccie crucifix microdosing.`,
  },
  {
    id: 21,
    title: "카페라떼",
    category: "샌드위치카페",
    price: 2900,
    img: "./images/item-22.jpg",
    desc: `skateboard fam synth authentic semiotics. Live-edge lyft af, edison bulb yuccie crucifix microdosing.`,
  },
  {
    id: 22,
    title: "카페모카",
    category: "샌드위치카페",
    price: 3200,
    img: "./images/item-23.jpg",
    desc: `skateboard fam synth authentic semiotics. Live-edge lyft af, edison bulb yuccie crucifix microdosing.`,
  },
  {
    id: 23,
    title: "돌체라떼",
    category: "샌드위치카페",
    price: 3200,
    img: "./images/item-24.jpg",
    desc: `skateboard fam synth authentic semiotics. Live-edge lyft af, edison bulb yuccie crucifix microdosing.`,
  },
  {
    id: 24,
    title: "복숭아아이스티",
    category: "샌드위치카페",
    price: 2300,
    img: "./images/item-25.jpg",
    desc: `skateboard fam synth authentic semiotics. Live-edge lyft af, edison bulb yuccie crucifix microdosing.`,
  },
  {
    id: 25,
    title: "아샷추",
    category: "샌드위치카페",
    price: 2800,
    img: "./images/item-26.jpg",
    desc: `skateboard fam synth authentic semiotics. Live-edge lyft af, edison bulb yuccie crucifix microdosing.`,
  },
  {
    id: 26,
    title: "햄치즈토스트",
    category: "토스트",
    price: 22.99,
    img: "./images/item-27.jpg",
    desc: `skateboard fam synth authentic semiotics. Live-edge lyft af, edison bulb yuccie crucifix microdosing.`,
  },
  {
    id: 27,
    title: "에그토스트",
    category: "토스트",
    price: 22.99,
    img: "./images/item-28.jpg",
    desc: `skateboard fam synth authentic semiotics. Live-edge lyft af, edison bulb yuccie crucifix microdosing.`,
  },
  
];
// get parent element
const sectionCenter = document.querySelector(".section-center");
const btnContainer = document.querySelector(".btn-container");
// display all items when page loads
window.addEventListener("DOMContentLoaded", function () {
  diplayMenuItems(menu);
  displayMenuButtons();
});

function diplayMenuItems(menuItems) {
  let displayMenu = menuItems.map(function (item) {
    // console.log(item);

    return `<article class="menu-item">
          <img src=${item.img} alt=${item.title} class="photo" />
          <div class="item-info">
            <header>
              <h4>${item.title}</h4>
              <h4 class="price">$${item.price}</h4>
            </header>
            <p class="item-text">
              ${item.desc}
            </p>
          </div>
        </article>`;
  });
  displayMenu = displayMenu.join("");
  // console.log(displayMenu);

  sectionCenter.innerHTML = displayMenu;
}
function displayMenuButtons() {
  const categories = menu.reduce(
    function (values, item) {
      if (!values.includes(item.category)) {
        values.push(item.category);
      }
      return values;
    },
    ["all"]
  );
  const categoryBtns = categories
    .map(function (category) {
      return `<button type="button" class="filter-btn" data-id=${category}>
          ${category}
        </button>`;
    })
    .join("");

  btnContainer.innerHTML = categoryBtns;
  const filterBtns = btnContainer.querySelectorAll(".filter-btn");
  console.log(filterBtns);

  filterBtns.forEach(function (btn) {
    btn.addEventListener("click", function (e) {
      // console.log(e.currentTarget.dataset);
      const category = e.currentTarget.dataset.id;
      const menuCategory = menu.filter(function (menuItem) {
        // console.log(menuItem.category);
        if (menuItem.category === category) {
          return menuItem;
        }
      });
      if (category === "all") {
        diplayMenuItems(menu);
      } else {
        diplayMenuItems(menuCategory);
      }
    });
  });
}
